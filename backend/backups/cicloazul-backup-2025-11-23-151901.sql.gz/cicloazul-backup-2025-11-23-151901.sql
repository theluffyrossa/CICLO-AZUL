--
-- PostgreSQL database dump
--

-- Dumped from database version 14.19
-- Dumped by pg_dump version 14.17 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: enum_audit_logs_action; Type: TYPE; Schema: public; Owner: cicloazul
--

CREATE TYPE public.enum_audit_logs_action AS ENUM (
    'CREATE',
    'UPDATE',
    'DELETE',
    'LOGIN',
    'LOGOUT',
    'EXPORT'
);


ALTER TYPE public.enum_audit_logs_action OWNER TO cicloazul;

--
-- Name: enum_collections_approval_status; Type: TYPE; Schema: public; Owner: cicloazul
--

CREATE TYPE public.enum_collections_approval_status AS ENUM (
    'PENDING_APPROVAL',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public.enum_collections_approval_status OWNER TO cicloazul;

--
-- Name: enum_collections_status; Type: TYPE; Schema: public; Owner: cicloazul
--

CREATE TYPE public.enum_collections_status AS ENUM (
    'SCHEDULED',
    'IN_PROGRESS',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public.enum_collections_status OWNER TO cicloazul;

--
-- Name: enum_collections_treatment_type; Type: TYPE; Schema: public; Owner: cicloazul
--

CREATE TYPE public.enum_collections_treatment_type AS ENUM (
    'RECYCLING',
    'COMPOSTING',
    'REUSE',
    'LANDFILL',
    'ANIMAL_FEEDING'
);


ALTER TYPE public.enum_collections_treatment_type OWNER TO cicloazul;

--
-- Name: enum_gravimetric_data_source; Type: TYPE; Schema: public; Owner: cicloazul
--

CREATE TYPE public.enum_gravimetric_data_source AS ENUM (
    'MANUAL',
    'CSV_IMPORT',
    'API',
    'SCALE'
);


ALTER TYPE public.enum_gravimetric_data_source OWNER TO cicloazul;

--
-- Name: enum_lgpd_consents_legal_basis; Type: TYPE; Schema: public; Owner: cicloazul
--

CREATE TYPE public.enum_lgpd_consents_legal_basis AS ENUM (
    'CONSENT',
    'LEGITIMATE_INTEREST',
    'LEGAL_OBLIGATION',
    'CONTRACT'
);


ALTER TYPE public.enum_lgpd_consents_legal_basis OWNER TO cicloazul;

--
-- Name: enum_recipients_type; Type: TYPE; Schema: public; Owner: cicloazul
--

CREATE TYPE public.enum_recipients_type AS ENUM (
    'COMPOSTING_CENTER',
    'RECYCLING_ASSOCIATION',
    'LANDFILL',
    'INDIVIDUAL',
    'COOPERATIVE',
    'OTHER'
);


ALTER TYPE public.enum_recipients_type OWNER TO cicloazul;

--
-- Name: enum_users_role; Type: TYPE; Schema: public; Owner: cicloazul
--

CREATE TYPE public.enum_users_role AS ENUM (
    'ADMIN',
    'CLIENT'
);


ALTER TYPE public.enum_users_role OWNER TO cicloazul;

--
-- Name: enum_waste_types_category; Type: TYPE; Schema: public; Owner: cicloazul
--

CREATE TYPE public.enum_waste_types_category AS ENUM (
    'ORGANIC',
    'RECYCLABLE',
    'HAZARDOUS',
    'ELECTRONIC',
    'CONSTRUCTION',
    'OTHER'
);


ALTER TYPE public.enum_waste_types_category OWNER TO cicloazul;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: cicloazul
--

CREATE TABLE public.audit_logs (
    id uuid NOT NULL,
    user_id uuid,
    action public.enum_audit_logs_action NOT NULL,
    table_name character varying(100) NOT NULL,
    record_id uuid,
    before_data jsonb,
    after_data jsonb,
    ip_address inet,
    user_agent text,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO cicloazul;

--
-- Name: COLUMN audit_logs.user_id; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.audit_logs.user_id IS 'User who performed the action';


--
-- Name: COLUMN audit_logs.table_name; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.audit_logs.table_name IS 'Table affected by action';


--
-- Name: COLUMN audit_logs.record_id; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.audit_logs.record_id IS 'ID of affected record';


--
-- Name: COLUMN audit_logs.before_data; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.audit_logs.before_data IS 'Data before change';


--
-- Name: COLUMN audit_logs.after_data; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.audit_logs.after_data IS 'Data after change';


--
-- Name: COLUMN audit_logs.ip_address; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.audit_logs.ip_address IS 'IP address of request';


--
-- Name: COLUMN audit_logs.user_agent; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.audit_logs.user_agent IS 'User agent string';


--
-- Name: client_waste_types; Type: TABLE; Schema: public; Owner: cicloazul
--

CREATE TABLE public.client_waste_types (
    id uuid NOT NULL,
    client_id uuid NOT NULL,
    waste_type_id uuid NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.client_waste_types OWNER TO cicloazul;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: cicloazul
--

CREATE TABLE public.clients (
    id uuid NOT NULL,
    name character varying(200) NOT NULL,
    document character varying(18) NOT NULL,
    phone character varying(20),
    email character varying(255),
    address character varying(255),
    city character varying(100),
    state character varying(2),
    zip_code character varying(9),
    active boolean DEFAULT true NOT NULL,
    notes text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.clients OWNER TO cicloazul;

--
-- Name: COLUMN clients.document; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.clients.document IS 'CNPJ or CPF';


--
-- Name: collections; Type: TABLE; Schema: public; Owner: cicloazul
--

CREATE TABLE public.collections (
    id uuid NOT NULL,
    client_id uuid NOT NULL,
    unit_id uuid NOT NULL,
    waste_type_id uuid NOT NULL,
    user_id uuid NOT NULL,
    recipient_id uuid NOT NULL,
    collection_date timestamp with time zone NOT NULL,
    status public.enum_collections_status DEFAULT 'SCHEDULED'::public.enum_collections_status NOT NULL,
    treatment_type public.enum_collections_treatment_type NOT NULL,
    notes text,
    latitude numeric(10,8),
    longitude numeric(11,8),
    metadata jsonb,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted_at timestamp with time zone,
    approval_status public.enum_collections_approval_status DEFAULT 'PENDING_APPROVAL'::public.enum_collections_approval_status NOT NULL,
    approved_by uuid,
    approved_at timestamp with time zone,
    rejection_reason text
);


ALTER TABLE public.collections OWNER TO cicloazul;

--
-- Name: COLUMN collections.user_id; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.collections.user_id IS 'User responsible for collection';


--
-- Name: COLUMN collections.recipient_id; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.collections.recipient_id IS 'Final recipient/destination where waste is sent';


--
-- Name: COLUMN collections.treatment_type; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.collections.treatment_type IS 'Type of waste treatment applied';


--
-- Name: COLUMN collections.latitude; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.collections.latitude IS 'GPS latitude at collection time';


--
-- Name: COLUMN collections.longitude; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.collections.longitude IS 'GPS longitude at collection time';


--
-- Name: COLUMN collections.metadata; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.collections.metadata IS 'Additional metadata about the collection';


--
-- Name: COLUMN collections.approval_status; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.collections.approval_status IS 'Approval status for collection validation';


--
-- Name: COLUMN collections.approved_by; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.collections.approved_by IS 'Admin user who approved/rejected the collection';


--
-- Name: COLUMN collections.approved_at; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.collections.approved_at IS 'Timestamp when collection was approved/rejected';


--
-- Name: COLUMN collections.rejection_reason; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.collections.rejection_reason IS 'Reason for rejection if status is REJECTED';


--
-- Name: gravimetric_data; Type: TABLE; Schema: public; Owner: cicloazul
--

CREATE TABLE public.gravimetric_data (
    id uuid NOT NULL,
    collection_id uuid NOT NULL,
    weight_kg numeric(10,2) NOT NULL,
    source public.enum_gravimetric_data_source DEFAULT 'MANUAL'::public.enum_gravimetric_data_source NOT NULL,
    device_id character varying(100),
    metadata jsonb,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.gravimetric_data OWNER TO cicloazul;

--
-- Name: COLUMN gravimetric_data.weight_kg; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.gravimetric_data.weight_kg IS 'Weight in kilograms';


--
-- Name: COLUMN gravimetric_data.device_id; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.gravimetric_data.device_id IS 'Device or scale identifier';


--
-- Name: COLUMN gravimetric_data.metadata; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.gravimetric_data.metadata IS 'Additional metadata from source';


--
-- Name: images; Type: TABLE; Schema: public; Owner: cicloazul
--

CREATE TABLE public.images (
    id uuid NOT NULL,
    collection_id uuid NOT NULL,
    url character varying(500) NOT NULL,
    url_medium character varying(500),
    url_small character varying(500),
    url_thumbnail character varying(500),
    storage_key character varying(255),
    filename character varying(255),
    mime_type character varying(100),
    file_size integer,
    width integer,
    height integer,
    latitude numeric(10,8),
    longitude numeric(11,8),
    captured_at timestamp with time zone,
    device_info character varying(100),
    consent_given boolean DEFAULT false NOT NULL,
    description text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.images OWNER TO cicloazul;

--
-- Name: COLUMN images.url; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.images.url IS 'File path or URL - Original size';


--
-- Name: COLUMN images.url_medium; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.images.url_medium IS 'URL for medium size thumbnail (800px)';


--
-- Name: COLUMN images.url_small; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.images.url_small IS 'URL for small size thumbnail (400px)';


--
-- Name: COLUMN images.url_thumbnail; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.images.url_thumbnail IS 'URL for thumbnail (200px)';


--
-- Name: COLUMN images.storage_key; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.images.storage_key IS 'S3 key for cloud storage';


--
-- Name: COLUMN images.file_size; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.images.file_size IS 'File size in bytes';


--
-- Name: COLUMN images.latitude; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.images.latitude IS 'GPS latitude where photo was taken';


--
-- Name: COLUMN images.longitude; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.images.longitude IS 'GPS longitude where photo was taken';


--
-- Name: COLUMN images.captured_at; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.images.captured_at IS 'Date/time photo was captured';


--
-- Name: COLUMN images.device_info; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.images.device_info IS 'Device used to capture';


--
-- Name: COLUMN images.consent_given; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.images.consent_given IS 'LGPD consent for images containing people';


--
-- Name: lgpd_consents; Type: TABLE; Schema: public; Owner: cicloazul
--

CREATE TABLE public.lgpd_consents (
    id uuid NOT NULL,
    client_id uuid NOT NULL,
    consent_type character varying(100) NOT NULL,
    legal_basis public.enum_lgpd_consents_legal_basis DEFAULT 'CONSENT'::public.enum_lgpd_consents_legal_basis NOT NULL,
    granted boolean DEFAULT false NOT NULL,
    granted_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    collected_by uuid,
    notes text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.lgpd_consents OWNER TO cicloazul;

--
-- Name: COLUMN lgpd_consents.consent_type; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.lgpd_consents.consent_type IS 'Type of consent (data_processing, image_use, etc)';


--
-- Name: COLUMN lgpd_consents.revoked_at; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.lgpd_consents.revoked_at IS 'When consent was revoked';


--
-- Name: COLUMN lgpd_consents.collected_by; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.lgpd_consents.collected_by IS 'User who collected consent';


--
-- Name: COLUMN lgpd_consents.notes; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.lgpd_consents.notes IS 'Additional notes about consent';


--
-- Name: recipients; Type: TABLE; Schema: public; Owner: cicloazul
--

CREATE TABLE public.recipients (
    id uuid NOT NULL,
    client_id uuid,
    name character varying(255) NOT NULL,
    type public.enum_recipients_type NOT NULL,
    document character varying(20),
    secondary_document character varying(20),
    address character varying(255),
    city character varying(100),
    state character varying(2),
    zip_code character varying(10),
    phone character varying(20),
    email character varying(255),
    responsible_name character varying(255),
    responsible_phone character varying(20),
    active boolean DEFAULT true NOT NULL,
    notes text,
    accepted_waste_types json,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.recipients OWNER TO cicloazul;

--
-- Name: units; Type: TABLE; Schema: public; Owner: cicloazul
--

CREATE TABLE public.units (
    id uuid NOT NULL,
    client_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    type character varying(100),
    address character varying(255),
    city character varying(100),
    state character varying(2),
    zip_code character varying(9),
    latitude numeric(10,8),
    longitude numeric(11,8),
    responsible_name character varying(100),
    responsible_phone character varying(20),
    active boolean DEFAULT true NOT NULL,
    notes text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.units OWNER TO cicloazul;

--
-- Name: COLUMN units.type; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.units.type IS 'Type of establishment (factory, office, etc)';


--
-- Name: COLUMN units.latitude; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.units.latitude IS 'GPS latitude';


--
-- Name: COLUMN units.longitude; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.units.longitude IS 'GPS longitude';


--
-- Name: COLUMN units.responsible_name; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.units.responsible_name IS 'Responsible person at unit';


--
-- Name: users; Type: TABLE; Schema: public; Owner: cicloazul
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(255),
    password character varying(255) NOT NULL,
    role public.enum_users_role DEFAULT 'CLIENT'::public.enum_users_role NOT NULL,
    active boolean DEFAULT true NOT NULL,
    last_login_at timestamp with time zone,
    client_id uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO cicloazul;

--
-- Name: waste_types; Type: TABLE; Schema: public; Owner: cicloazul
--

CREATE TABLE public.waste_types (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    category public.enum_waste_types_category NOT NULL,
    description text,
    unit character varying(50),
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.waste_types OWNER TO cicloazul;

--
-- Name: COLUMN waste_types.unit; Type: COMMENT; Schema: public; Owner: cicloazul
--

COMMENT ON COLUMN public.waste_types.unit IS 'Unit of measurement (kg, L, m³)';


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: cicloazul
--

COPY public.audit_logs (id, user_id, action, table_name, record_id, before_data, after_data, ip_address, user_agent, created_at) FROM stdin;
f6eb6a2b-e183-47a1-b873-7f01f52dd1ec	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGIN	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-16 00:09:32.619+00
a518167f-ce2f-45ff-b7de-fccf939348cd	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGOUT	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-16 00:10:28.117+00
23f281f4-5ba6-44fc-880b-c2994ae66731	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGIN	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-16 00:10:32.127+00
db837c6c-c78e-46a5-aec2-df0847169d63	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGOUT	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-16 00:11:47.549+00
5560a236-84f5-4cdf-baac-d920f2fb62fd	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGIN	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-16 00:11:57.979+00
1143db88-59e2-4fd0-a588-ad8581bb37bc	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGOUT	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-16 00:13:12.394+00
cfff7ddb-0748-44db-81a2-4d35310ff3fc	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGIN	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-16 00:13:17.508+00
7da0da88-2669-4369-bb98-933f2ad7ba34	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGOUT	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-16 00:13:29.238+00
c752e015-d729-4764-9bc0-fb3f1f8ea092	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGIN	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-16 00:13:34.147+00
ca90441e-ef57-4b36-9050-7d80f5106d69	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGOUT	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-16 22:35:10.986+00
232e0069-28ab-4a7a-94d2-39f32775de40	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGIN	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-16 22:35:15.716+00
64e90152-f98f-42ea-be3a-38bb8b16e0fb	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGOUT	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-16 22:39:12.273+00
c1da76a4-68ac-4a16-8df1-e22620a1f01e	1b38d0df-23f8-4b20-af12-76044ca4e12d	LOGIN	users	1b38d0df-23f8-4b20-af12-76044ca4e12d	\N	\N	172.20.10.1	\N	2025-11-16 22:39:19.437+00
de542147-f1e8-4539-9b88-10705e9a0453	1b38d0df-23f8-4b20-af12-76044ca4e12d	LOGOUT	users	1b38d0df-23f8-4b20-af12-76044ca4e12d	\N	\N	172.20.10.1	\N	2025-11-16 22:39:26.165+00
2f4146c9-7c51-4601-8720-66a91767f0fd	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGIN	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-16 22:39:30.688+00
ca87054b-2a36-4bf6-81e0-5cd4ebba4631	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGIN	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	127.0.0.1	\N	2025-11-16 22:48:08.834+00
0eaab072-34ee-431c-b44d-66f991a5a191	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGIN	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	127.0.0.1	\N	2025-11-16 22:50:00.543+00
edf4cb38-0893-4503-9ef4-89fb1a0ce3b5	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGOUT	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-16 22:53:09.811+00
34daa889-cf0d-4e6b-a975-6e3271fddb3f	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGIN	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-16 23:10:06.411+00
29a0bbf2-4895-43d2-bb65-092b42016e27	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGOUT	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-16 23:14:48.36+00
3339d4e1-ec5a-4603-b204-e199b6b6f4a5	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGIN	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-16 23:14:53.358+00
454a2d55-1dfa-4b02-aa76-4b99c4a00763	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGOUT	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-16 23:15:09.655+00
49328659-baff-4433-911c-0dacb70d3407	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGIN	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-16 23:15:13.788+00
974ab70f-9826-4f40-96ba-7c3c403b45a2	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGOUT	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-16 23:15:26.578+00
865921c8-8049-4361-b9d8-ef50f34510ec	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGIN	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-16 23:15:36.414+00
b65912ac-a43b-4fb4-91d5-8085dc406818	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGOUT	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-16 23:18:03.044+00
9e4a5053-d12e-4e4c-9cdb-6474c332f9aa	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGIN	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-16 23:18:07.573+00
68dbfb4e-0f17-48e2-8436-6e845cb24063	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGOUT	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-17 22:00:24.405+00
36131ff9-5c0a-4532-8c65-b67a39add6ef	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGIN	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-17 22:06:40.261+00
8d0f12a2-4642-4f17-bafc-684f71e26044	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGOUT	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-17 22:09:45.393+00
88cb3a1d-2983-4e2a-9530-61df3c030d13	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGIN	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-17 22:09:51.424+00
97f4cb26-174e-42b4-95b0-aa1ae30f6a19	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGOUT	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-17 22:14:47.43+00
2678ae54-73eb-4c58-ab27-37b6bf8e3197	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGIN	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-17 22:14:52.673+00
2781cb65-3fff-4bfc-8b36-1a6dc8921034	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGOUT	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-22 15:54:05.038+00
a0001c1d-c52f-4522-9561-071b6645b91e	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGIN	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-22 16:59:04.386+00
4e637f07-cce8-48fc-b16c-14371671ce74	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGOUT	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-22 16:59:57.12+00
abf047e4-99d1-45b7-8aab-dfa3d8c3e38e	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGIN	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-22 17:00:01.816+00
ee9443e3-f65b-4d7a-b7dc-15c4d7a55279	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGOUT	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-22 17:14:40.722+00
24310298-2483-4ed6-b9bb-5cb1d2f07645	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGIN	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-22 17:14:46.873+00
1da1a258-9fcf-4cde-a35c-cc4d7ed02c89	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGOUT	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-22 17:14:52.465+00
dc46afcd-0fc1-4456-abdc-4c7881769422	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGIN	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-22 17:14:57.01+00
1b716e37-d03d-463a-ac8b-bf5b5ef3fa00	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGOUT	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-22 17:15:39.78+00
fea7d023-cd25-44db-b663-6768307062e4	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGIN	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-22 17:15:45.135+00
7cf83c0e-d749-47cb-806a-deff15ce3389	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGOUT	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-22 17:47:57.26+00
5415bc4b-c863-42a9-8d34-a3e2affef77e	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGIN	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-22 17:48:01.417+00
9b90c0f9-efe9-4ea4-89f2-8ca449dadee0	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGIN	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-22 17:53:12.007+00
16ce7233-776b-439f-8c5e-a83cdeb5a93a	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGOUT	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-22 19:33:05.026+00
1a7f590e-ed76-4933-902a-0febf0a23648	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGIN	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-22 19:33:10.036+00
915e9e10-ebe4-4ef4-ae41-51f221de3594	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGOUT	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-22 19:50:08.205+00
752a271d-b390-486c-b6c5-e06c442b3dc7	1b38d0df-23f8-4b20-af12-76044ca4e12d	LOGIN	users	1b38d0df-23f8-4b20-af12-76044ca4e12d	\N	\N	172.20.10.1	\N	2025-11-22 19:51:33.155+00
31c7ab6f-f692-4287-b35f-cd1105413a70	1b38d0df-23f8-4b20-af12-76044ca4e12d	LOGOUT	users	1b38d0df-23f8-4b20-af12-76044ca4e12d	\N	\N	172.20.10.1	\N	2025-11-22 19:52:11.538+00
cddadb4e-791e-4d1c-9f46-08ea3d12f549	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGIN	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-22 19:52:16.138+00
6487a8d7-4543-47c9-a920-7c5a207f5f33	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGOUT	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-22 20:34:37.257+00
073dcb53-9f66-44aa-a04a-9ef0a9bba1e6	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGIN	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-22 20:34:43.564+00
e672de4f-3c2d-481f-9bd0-14b1b43364ae	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGOUT	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-22 20:39:18.062+00
3a4026dd-8660-463e-9ee8-4016389da041	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGIN	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-22 20:39:22.47+00
7f1022f8-7c1a-406d-bb69-f96a85f0900e	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGOUT	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-22 20:39:32.985+00
1f540e85-ca88-471a-8dea-77a2eb6f14e1	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGIN	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-22 20:39:39.137+00
7895efb8-69e5-4ae2-98ea-68f4e78dc860	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGOUT	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-23 15:35:57.108+00
14347b2c-34b1-44e2-ab7c-1b0ee2b86d71	1b38d0df-23f8-4b20-af12-76044ca4e12d	LOGIN	users	1b38d0df-23f8-4b20-af12-76044ca4e12d	\N	\N	172.20.10.1	\N	2025-11-23 15:36:33.357+00
75d9bf89-3414-45a8-8114-8eb61aa6c9b1	1b38d0df-23f8-4b20-af12-76044ca4e12d	LOGOUT	users	1b38d0df-23f8-4b20-af12-76044ca4e12d	\N	\N	172.20.10.1	\N	2025-11-23 15:38:38.735+00
32284626-dc7e-4443-b614-37ebf62eba9e	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGIN	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-23 15:38:43.362+00
42b342b6-adce-4ae2-9c53-30fdb989ef7c	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGOUT	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-23 15:40:18.19+00
2835c00b-20db-4fa9-8274-6d3b5e5daa68	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGIN	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-23 15:40:39.964+00
5594dc4a-ce41-4fe0-870a-c70a013820c1	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGOUT	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-23 15:45:07.896+00
ad4b522b-d4dd-458a-bc53-93e811a53224	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGIN	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-23 15:45:19.278+00
1a688948-074c-4985-9231-944e42535e6e	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGOUT	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-23 15:45:53.299+00
8c63e63c-7f32-40e7-b6c6-42063f72d066	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGIN	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-23 15:46:05.547+00
e983a448-e44f-460b-968f-26df945f0447	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGOUT	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-23 16:05:48.407+00
591f12c6-b7fc-4b40-8f6f-bed071fc9aa2	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGIN	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-23 16:05:53.438+00
833fda77-4a49-4212-a7b0-27e518d38c49	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	LOGOUT	users	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	\N	\N	172.20.10.1	\N	2025-11-23 17:44:10.801+00
4a1f780f-1032-428e-8378-cb247bf4b288	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGIN	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-23 17:44:17.177+00
8847940c-85fb-4cff-b6d1-60ab46583117	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGOUT	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-23 17:47:15.054+00
083ca581-66f3-42b9-a296-36bc0f69967e	6a4ace4e-5060-435c-b800-fe505fe08ec5	LOGIN	users	6a4ace4e-5060-435c-b800-fe505fe08ec5	\N	\N	172.20.10.1	\N	2025-11-23 17:47:31.846+00
\.


--
-- Data for Name: client_waste_types; Type: TABLE DATA; Schema: public; Owner: cicloazul
--

COPY public.client_waste_types (id, client_id, waste_type_id, active, created_at, updated_at) FROM stdin;
c818ea70-052f-4cc6-af8c-17f40065b6ba	7209ebbc-98f2-49b5-8023-7476ddeee8d4	aad03eb4-3539-450a-b77f-130ee71c873e	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
fdb1fbe7-9a05-46ff-994d-1a68b8b06a1c	7209ebbc-98f2-49b5-8023-7476ddeee8d4	9ef6eb5f-91fb-40fa-8dd4-b29f5e8a55bb	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
f030988b-fede-4d29-9408-97bbc88fc797	7209ebbc-98f2-49b5-8023-7476ddeee8d4	4f6268b8-bf14-49d1-a427-cb288bca35d8	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
5aa76f5d-d08f-4b96-826a-68b4c0afd354	7209ebbc-98f2-49b5-8023-7476ddeee8d4	986cedc0-03b4-4a97-acd0-251418813e58	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
37d51e53-0c03-45a6-9fd0-e0d5bfcf7e29	7209ebbc-98f2-49b5-8023-7476ddeee8d4	46dcf1a7-021c-42b0-a1a1-1674fbc341e5	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
78a30c82-753b-4c77-a24d-65ab248dfd33	7209ebbc-98f2-49b5-8023-7476ddeee8d4	9fea2fd7-bb95-4e2a-87d5-5102f74a89ba	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
92f72508-7064-4ae0-a8eb-6d3cbf654240	7209ebbc-98f2-49b5-8023-7476ddeee8d4	a0d6d060-b857-4679-8944-a33f08473903	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
810b66f1-2556-488c-b7cf-0cba5fdb75a0	7209ebbc-98f2-49b5-8023-7476ddeee8d4	5b440a7d-b4f5-46a7-bdcd-ce4a0353d461	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
fa6d8cba-0b69-4b8c-a65f-6a0daab48d16	7209ebbc-98f2-49b5-8023-7476ddeee8d4	ad6431b4-fc85-4a24-84df-a4e8bec3abc1	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
02db6eb4-c031-4300-8c7d-33d256104bde	7209ebbc-98f2-49b5-8023-7476ddeee8d4	ea6c40ac-3c49-415d-8b98-e9b053f739c3	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
85083a79-016a-463b-93b9-91b1ea6c1fce	7209ebbc-98f2-49b5-8023-7476ddeee8d4	c9263448-02b2-4eb5-8e0c-809788f7fc4f	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
978525ed-6d35-4cdc-bcda-703af5f3d52f	7209ebbc-98f2-49b5-8023-7476ddeee8d4	e1b23eec-1e65-4819-85e0-ecddf6123472	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
33305b21-0b3c-4a25-a1e1-3ee7cf26ccd7	7209ebbc-98f2-49b5-8023-7476ddeee8d4	1406ff0f-616c-40c4-bd7f-dbac8c00bcc8	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
e2d67dd0-23c4-4f56-91b0-a65a5698d2a4	7209ebbc-98f2-49b5-8023-7476ddeee8d4	6bdf4172-1f3d-446a-9399-fdb90a9bc290	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
b947e60a-1356-4045-bba5-f22021542fa6	7209ebbc-98f2-49b5-8023-7476ddeee8d4	a255ed6c-0108-4024-8534-729b85533925	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
f75c1be3-eb97-46cf-98f9-1b4464fa43cc	7209ebbc-98f2-49b5-8023-7476ddeee8d4	8e23bc19-f38a-4ce1-a0ea-6716da308080	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
8db133c6-b836-4e9c-8d10-5651e236a188	7209ebbc-98f2-49b5-8023-7476ddeee8d4	efe6ba0f-c3a5-43f3-9686-1ad6e2a5e838	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
f10e20bd-9a22-4963-ba9a-d140ea8f133a	560d629c-b877-44fb-a79f-552bcd318aee	e1b23eec-1e65-4819-85e0-ecddf6123472	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
ed0bdf50-850e-4cb8-8bbd-559ecf1c8802	560d629c-b877-44fb-a79f-552bcd318aee	136bc894-9f1a-48e5-b6a2-346a03849c25	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
96b7aded-2390-4d00-8721-e97f30000d4e	560d629c-b877-44fb-a79f-552bcd318aee	c9263448-02b2-4eb5-8e0c-809788f7fc4f	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
96f5fe1e-88d0-43dc-8124-b064e8d7679c	560d629c-b877-44fb-a79f-552bcd318aee	986cedc0-03b4-4a97-acd0-251418813e58	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
4570295b-3cb6-4744-b0fa-4252e6b426c3	560d629c-b877-44fb-a79f-552bcd318aee	9ef6eb5f-91fb-40fa-8dd4-b29f5e8a55bb	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
9de0ee76-7c82-4a15-9a72-f64d7d444aeb	560d629c-b877-44fb-a79f-552bcd318aee	4f6268b8-bf14-49d1-a427-cb288bca35d8	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
87f5fd0b-f5b2-4c82-b935-26960bfa08b5	560d629c-b877-44fb-a79f-552bcd318aee	0857a511-42d8-4b0d-833c-283ac4ca86e8	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
1012c0a3-1c42-4654-9b3d-11b00386c9f2	560d629c-b877-44fb-a79f-552bcd318aee	8e23bc19-f38a-4ce1-a0ea-6716da308080	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
92281998-0444-4619-9fb0-bf9533a11269	560d629c-b877-44fb-a79f-552bcd318aee	ea6c40ac-3c49-415d-8b98-e9b053f739c3	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
714ef59a-90d5-4a30-b1d1-18f0cae86415	560d629c-b877-44fb-a79f-552bcd318aee	5b440a7d-b4f5-46a7-bdcd-ce4a0353d461	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
4a452cc5-9b0e-4832-8d7d-b3be7243bf37	560d629c-b877-44fb-a79f-552bcd318aee	ad6431b4-fc85-4a24-84df-a4e8bec3abc1	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
b1c3a37a-fbdf-4bd7-8498-b4c0837eb887	560d629c-b877-44fb-a79f-552bcd318aee	46dcf1a7-021c-42b0-a1a1-1674fbc341e5	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
90c524fd-706f-4c99-ba82-41af9f0e5e1f	560d629c-b877-44fb-a79f-552bcd318aee	31d0bcd9-2c27-4634-b6c7-21443f06523e	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
f1b46df0-7721-455a-8d04-c6bbbece7c97	560d629c-b877-44fb-a79f-552bcd318aee	6bdf4172-1f3d-446a-9399-fdb90a9bc290	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
e2cad142-b267-4983-8f0f-bd6ba75a5269	560d629c-b877-44fb-a79f-552bcd318aee	1406ff0f-616c-40c4-bd7f-dbac8c00bcc8	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
10a69c5b-27db-460a-980d-3ad76b3eb007	560d629c-b877-44fb-a79f-552bcd318aee	a0d6d060-b857-4679-8944-a33f08473903	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
ab5807e1-a1b0-4b93-b6fb-48bb14b31a42	560d629c-b877-44fb-a79f-552bcd318aee	9fea2fd7-bb95-4e2a-87d5-5102f74a89ba	t	2025-11-16 00:08:00.892+00	2025-11-16 00:08:00.892+00
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: cicloazul
--

COPY public.clients (id, name, document, phone, email, address, city, state, zip_code, active, notes, created_at, updated_at, deleted_at) FROM stdin;
7209ebbc-98f2-49b5-8023-7476ddeee8d4	PARQUE ECOLÓGICO RIO FORMOSO LTDA	04.495.804/0001-60	(67) 98162-5580	financeiro@parquerioformoso.com.br	Rodovia Bonito / Guia Lopes Da Laguna, S/N Km 07 - Zona Rural	Bonito	MS	79290-000	t	Cliente Piloto - Parque Ecológico Rio Formoso e Restaurante da Lagoa	2025-11-16 00:08:00.77+00	2025-11-16 00:08:00.77+00	\N
560d629c-b877-44fb-a79f-552bcd318aee	C&S BARES E RESTAURANTES LTDA	49.870.410/0001-82	(67) 98473-8342	bacuricozinharegional@gmail.com	Rua 24 de Fevereiro, 2268, Centro	Bonito	MS	79290-000	t	Cliente Piloto - BACURI Cozinha Regional	2025-11-16 00:08:00.77+00	2025-11-16 00:08:00.77+00	\N
\.


--
-- Data for Name: collections; Type: TABLE DATA; Schema: public; Owner: cicloazul
--

COPY public.collections (id, client_id, unit_id, waste_type_id, user_id, recipient_id, collection_date, status, treatment_type, notes, latitude, longitude, metadata, created_at, updated_at, deleted_at, approval_status, approved_by, approved_at, rejection_reason) FROM stdin;
3b986a7a-8590-4c33-a41a-5455d11f4761	560d629c-b877-44fb-a79f-552bcd318aee	ee618271-fb2f-48a3-8be3-5186ced637a7	a0d6d060-b857-4679-8944-a33f08473903	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	d92f7f52-2234-4750-9868-11caadd2c7b8	2025-11-22 17:14:59.026+00	COMPLETED	RECYCLING	\N	-15.62488311	-56.05077148	{"responsibleName": "Luffy"}	2025-11-22 17:15:25.66+00	2025-11-22 17:44:08.261+00	\N	APPROVED	6a4ace4e-5060-435c-b800-fe505fe08ec5	2025-11-22 17:44:08.26+00	\N
1e38a7e4-5f51-4ec5-b885-1434cbd0028d	560d629c-b877-44fb-a79f-552bcd318aee	ee618271-fb2f-48a3-8be3-5186ced637a7	9ef6eb5f-91fb-40fa-8dd4-b29f5e8a55bb	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	56396f51-2b27-4bd7-8c0c-493f702216b2	2025-11-22 17:48:03.488+00	COMPLETED	REUSE	\N	-15.62478789	-56.05066470	{"responsibleName": "E"}	2025-11-22 17:50:47.005+00	2025-11-22 19:33:33.224+00	\N	APPROVED	6a4ace4e-5060-435c-b800-fe505fe08ec5	2025-11-22 19:33:33.22+00	\N
2248f362-1208-46e5-bf91-8fd3438568ec	7209ebbc-98f2-49b5-8023-7476ddeee8d4	38aa841e-7439-4f63-bc6c-e29b05878cfc	986cedc0-03b4-4a97-acd0-251418813e58	1b38d0df-23f8-4b20-af12-76044ca4e12d	4d90b17d-3c68-4fdb-ba89-8cf3d0c50ff9	2025-11-22 19:51:35.383+00	COMPLETED	ANIMAL_FEEDING	\N	-15.62488641	-56.05050861	{"responsibleName": "Eu"}	2025-11-22 19:51:59.858+00	2025-11-22 19:52:26.37+00	\N	APPROVED	6a4ace4e-5060-435c-b800-fe505fe08ec5	2025-11-22 19:52:26.37+00	\N
fcf1395c-f4ff-4960-96ec-8202fe370845	7209ebbc-98f2-49b5-8023-7476ddeee8d4	38aa841e-7439-4f63-bc6c-e29b05878cfc	5b440a7d-b4f5-46a7-bdcd-ce4a0353d461	1b38d0df-23f8-4b20-af12-76044ca4e12d	de02e23b-23ec-4129-b54e-175e7626aabc	2025-11-23 15:37:21.334+00	COMPLETED	RECYCLING	\N	-15.62484543	-56.05073151	{"responsibleName": "Luffy "}	2025-11-23 15:37:54.092+00	2025-11-23 15:39:26.288+00	\N	APPROVED	6a4ace4e-5060-435c-b800-fe505fe08ec5	2025-11-23 15:39:26.287+00	\N
48161487-b6b1-4fda-9ce8-00bd2cb639b0	560d629c-b877-44fb-a79f-552bcd318aee	ee618271-fb2f-48a3-8be3-5186ced637a7	9fea2fd7-bb95-4e2a-87d5-5102f74a89ba	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	d64c53f7-30ba-4c61-b3b4-aa041c02b473	2025-11-23 15:40:41.971+00	SCHEDULED	LANDFILL	\N	-15.62477307	-56.05055088	{"responsibleName": "Luffy"}	2025-11-23 15:43:40.281+00	2025-11-23 15:43:40.281+00	\N	PENDING_APPROVAL	\N	\N	\N
32767153-e150-42c9-a3a4-bf5f554fdc83	560d629c-b877-44fb-a79f-552bcd318aee	ee618271-fb2f-48a3-8be3-5186ced637a7	ea6c40ac-3c49-415d-8b98-e9b053f739c3	006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	d2d7a11c-4e18-4259-8097-09daa710bc36	2025-11-23 15:45:20.896+00	SCHEDULED	LANDFILL	\N	-15.62484543	-56.05073151	{"responsibleName": "Eu "}	2025-11-23 15:45:45.308+00	2025-11-23 16:00:50.679+00	\N	REJECTED	6a4ace4e-5060-435c-b800-fe505fe08ec5	2025-11-23 16:00:50.678+00	Não quis é
\.


--
-- Data for Name: gravimetric_data; Type: TABLE DATA; Schema: public; Owner: cicloazul
--

COPY public.gravimetric_data (id, collection_id, weight_kg, source, device_id, metadata, created_at, updated_at) FROM stdin;
b88acdf4-d657-4917-8600-05bc0b57bc29	3b986a7a-8590-4c33-a41a-5455d11f4761	10.00	MANUAL	ios	{"platform": "ios", "appVersion": "1.0.0"}	2025-11-22 17:15:26.221+00	2025-11-22 17:15:26.221+00
ade6a299-db93-457a-8af5-42043ea1d7a0	1e38a7e4-5f51-4ec5-b885-1434cbd0028d	11.00	MANUAL	ios	{"platform": "ios", "appVersion": "1.0.0"}	2025-11-22 17:50:47.472+00	2025-11-22 17:50:47.472+00
b81b0e7a-735c-4c64-9e8e-7e5fa02319d0	2248f362-1208-46e5-bf91-8fd3438568ec	20.77	MANUAL	ios	{"platform": "ios", "appVersion": "1.0.0"}	2025-11-22 19:52:00.457+00	2025-11-22 19:52:00.457+00
c133c470-43bc-4ac9-936c-6a94ea370d01	fcf1395c-f4ff-4960-96ec-8202fe370845	5.00	MANUAL	ios	{"platform": "ios", "appVersion": "1.0.0"}	2025-11-23 15:37:57.448+00	2025-11-23 15:37:57.448+00
702dc2a7-40b0-4b71-a883-ec871286c22f	48161487-b6b1-4fda-9ce8-00bd2cb639b0	5.70	MANUAL	ios	{"platform": "ios", "appVersion": "1.0.0"}	2025-11-23 15:43:42.739+00	2025-11-23 15:43:42.739+00
f125ddee-bf91-43bb-b514-bb351b994364	32767153-e150-42c9-a3a4-bf5f554fdc83	2.00	MANUAL	ios	{"platform": "ios", "appVersion": "1.0.0"}	2025-11-23 15:45:47.119+00	2025-11-23 15:45:47.119+00
\.


--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: cicloazul
--

COPY public.images (id, collection_id, url, url_medium, url_small, url_thumbnail, storage_key, filename, mime_type, file_size, width, height, latitude, longitude, captured_at, device_info, consent_given, description, created_at, updated_at, deleted_at) FROM stdin;
6c230431-5062-491b-9315-34e3437d539a	fcf1395c-f4ff-4960-96ec-8202fe370845	https://ciclo-azul-img-coletas.s3.us-east-2.amazonaws.com/images/1763912274519-5083984e239d3451-original-1763912274514-photo-1763912274134-0.jpg	https://ciclo-azul-img-coletas.s3.us-east-2.amazonaws.com/images/1763912276571-252b2087dd4c2c83-medium-1763912276571-photo-1763912274134-0.jpg	https://ciclo-azul-img-coletas.s3.us-east-2.amazonaws.com/images/1763912276855-64b7b9f6b34b5397-small-1763912276855-photo-1763912274134-0.jpg	https://ciclo-azul-img-coletas.s3.us-east-2.amazonaws.com/images/1763912277110-5bb676cec0587b59-thumb-1763912277110-photo-1763912274134-0.jpg	images/1763912274519-5083984e239d3451-original-1763912274514-photo-1763912274134-0.jpg	photo-1763912274134-0.jpg	image/jpeg	113669	1080	1080	-15.62484543	-56.05073151	2025-11-23 15:37:56.571+00	\N	t	\N	2025-11-23 15:37:57.36+00	2025-11-23 15:37:57.36+00	\N
811b72c2-b7d7-4c19-af5e-8c9e366dfc16	48161487-b6b1-4fda-9ce8-00bd2cb639b0	https://ciclo-azul-img-coletas.s3.us-east-2.amazonaws.com/images/1763912620634-df9fb5ac7ac07aa7-original-1763912620634-photo-1763912620340-0.jpg	https://ciclo-azul-img-coletas.s3.us-east-2.amazonaws.com/images/1763912621974-247bacc5b4d777db-medium-1763912621974-photo-1763912620340-0.jpg	https://ciclo-azul-img-coletas.s3.us-east-2.amazonaws.com/images/1763912622214-0c1a601a44b2af19-small-1763912622214-photo-1763912620340-0.jpg	https://ciclo-azul-img-coletas.s3.us-east-2.amazonaws.com/images/1763912622448-e29fbc68fcff441a-thumb-1763912622448-photo-1763912620340-0.jpg	images/1763912620634-df9fb5ac7ac07aa7-original-1763912620634-photo-1763912620340-0.jpg	photo-1763912620340-0.jpg	image/jpeg	81496	1080	1080	-15.62477307	-56.05055088	2025-11-23 15:43:41.974+00	\N	t	\N	2025-11-23 15:43:42.686+00	2025-11-23 15:43:42.686+00	\N
975a9600-53dc-4631-ada7-00328dceb7ba	32767153-e150-42c9-a3a4-bf5f554fdc83	https://ciclo-azul-img-coletas.s3.us-east-2.amazonaws.com/images/1763912745677-7b9e260abf8350ad-original-1763912745673-photo-1763912745354-0.jpg	\N	\N	\N	images/1763912745677-7b9e260abf8350ad-original-1763912745673-photo-1763912745354-0.jpg	photo-1763912745354-0.jpg	image/jpeg	113513	1080	1080	-15.62484543	-56.05073151	2025-11-23 15:45:47.055+00	\N	t	\N	2025-11-23 15:45:47.057+00	2025-11-23 15:45:47.057+00	\N
e230184f-864c-41c7-ab98-27744986a0ba	3b986a7a-8590-4c33-a41a-5455d11f4761	https://ciclo-azul-img-coletas.s3.us-east-2.amazonaws.com/images/1763831726158-eec367641482f6d0-original-1763831726158-photo-1763831725885-0.jpg	http://localhost:3000/uploads/images/1763831726159-959bb280fc3a585a-medium-1763831726159-photo-1763831725885-0.jpg	http://localhost:3000/uploads/images/1763831726160-4f123961c8822a29-small-1763831726160-photo-1763831725885-0.jpg	http://localhost:3000/uploads/images/1763831726160-75785c7566546aaa-thumb-1763831726160-photo-1763831725885-0.jpg	images/1763831726158-eec367641482f6d0-original-1763831726158-photo-1763831725885-0.jpg	photo-1763831725885-0.jpg	image/jpeg	175762	1080	1080	-15.62488311	-56.05077148	2025-11-22 17:15:26.159+00	\N	t	\N	2025-11-22 17:15:26.161+00	2025-11-23 16:00:23.133+00	\N
bcdce23b-2000-432f-be6a-374cc4a21b8d	1e38a7e4-5f51-4ec5-b885-1434cbd0028d	https://ciclo-azul-img-coletas.s3.us-east-2.amazonaws.com/images/1763833847409-b14b0fc08f9580fe-original-1763833847409-photo-1763833847123-0.jpg	http://localhost:3000/uploads/images/1763833847411-6163271cd1f10ddc-medium-1763833847411-photo-1763833847123-0.jpg	http://localhost:3000/uploads/images/1763833847412-a59b2976a4cf5c5e-small-1763833847412-photo-1763833847123-0.jpg	http://localhost:3000/uploads/images/1763833847413-8c8247cc13098dd1-thumb-1763833847413-photo-1763833847123-0.jpg	images/1763833847409-b14b0fc08f9580fe-original-1763833847409-photo-1763833847123-0.jpg	photo-1763833847123-0.jpg	image/jpeg	61560	1080	1080	-15.62478789	-56.05066470	2025-11-22 17:50:47.411+00	\N	t	\N	2025-11-22 17:50:47.415+00	2025-11-23 16:00:24.199+00	\N
0e87685e-e027-420f-b3ac-b268c4a6293d	2248f362-1208-46e5-bf91-8fd3438568ec	https://ciclo-azul-img-coletas.s3.us-east-2.amazonaws.com/images/1763841120392-e1edb9b17dc9db2c-original-1763841120391-photo-1763841120129-0.jpg	http://localhost:3000/uploads/images/1763841120395-c28c99c8df9c18cd-medium-1763841120395-photo-1763841120129-0.jpg	http://localhost:3000/uploads/images/1763841120395-d0216b36c950c9a7-small-1763841120395-photo-1763841120129-0.jpg	http://localhost:3000/uploads/images/1763841120396-56650c11c51a83f6-thumb-1763841120396-photo-1763841120129-0.jpg	images/1763841120392-e1edb9b17dc9db2c-original-1763841120391-photo-1763841120129-0.jpg	photo-1763841120129-0.jpg	image/jpeg	121042	1080	1080	-15.62488641	-56.05050861	2025-11-22 19:52:00.395+00	\N	t	\N	2025-11-22 19:52:00.397+00	2025-11-23 16:00:25.204+00	\N
\.


--
-- Data for Name: lgpd_consents; Type: TABLE DATA; Schema: public; Owner: cicloazul
--

COPY public.lgpd_consents (id, client_id, consent_type, legal_basis, granted, granted_at, revoked_at, collected_by, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: recipients; Type: TABLE DATA; Schema: public; Owner: cicloazul
--

COPY public.recipients (id, client_id, name, type, document, secondary_document, address, city, state, zip_code, phone, email, responsible_name, responsible_phone, active, notes, accepted_waste_types, created_at, updated_at, deleted_at) FROM stdin;
d92f7f52-2234-4750-9868-11caadd2c7b8	\N	Ciclo Azul Consultoria, Assessoria e Gestão Ambiental LTDA	COMPOSTING_CENTER	36.940.762/0001-15	\N	\N	Bonito	MS	\N	\N	\N	\N	\N	t	Clube da Compostagem - Recipient Global (disponível para todos)	["Orgânicos"]	2025-11-16 00:08:00.887+00	2025-11-16 00:08:00.887+00	\N
ec16ef95-02c2-4e6c-b3df-4733a0f7b0d1	7209ebbc-98f2-49b5-8023-7476ddeee8d4	Maria Aparecida da Silva Souza	INDIVIDUAL	954.154.161-53	\N	\N	Bonito	MS	\N	\N	\N	\N	\N	t	Recipient específico do Parque Rio Formoso	\N	2025-11-16 00:08:00.887+00	2025-11-16 00:08:00.887+00	\N
d2d7a11c-4e18-4259-8097-09daa710bc36	7209ebbc-98f2-49b5-8023-7476ddeee8d4	Maria de Fatima Nascimento	INDIVIDUAL	12.472.246/0001-45	75767058920	\N	Bonito	MS	\N	\N	\N	\N	\N	t	Recipient específico do Parque Rio Formoso	\N	2025-11-16 00:08:00.887+00	2025-11-16 00:08:00.887+00	\N
4d90b17d-3c68-4fdb-ba89-8cf3d0c50ff9	560d629c-b877-44fb-a79f-552bcd318aee	MARINALVA DOS SANTOS	INDIVIDUAL	42.172.344/0001-28	02958328198	\N	Bonito	MS	\N	\N	\N	\N	\N	t	Recipient específico do Bacuri	\N	2025-11-16 00:08:00.887+00	2025-11-16 00:08:00.887+00	\N
d64c53f7-30ba-4c61-b3b4-aa041c02b473	\N	Aterro Sanitário de Jardim - Consórcio Intermunicipal	LANDFILL	\N	\N	\N	Jardim	MS	\N	\N	\N	\N	\N	t	Recipient Global (disponível para todos)	["Rejeito"]	2025-11-16 00:08:00.887+00	2025-11-16 00:08:00.887+00	\N
56396f51-2b27-4bd7-8c0c-493f702216b2	\N	Associação de Recicladores de Lixo Eletro Eletrônicos de Mato Grosso do Sul	RECYCLING_ASSOCIATION	19.913.566/0001-32	\N	\N	\N	MS	\N	\N	\N	\N	\N	t	Recipient Global (disponível para todos)	["Metais em Geral","Alumínio"]	2025-11-16 00:08:00.887+00	2025-11-16 00:08:00.887+00	\N
de02e23b-23ec-4129-b54e-175e7626aabc	\N	Doação	OTHER	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	Destinatário genérico para doações - Recipient Global (disponível para todos)	\N	2025-11-16 00:08:00.887+00	2025-11-16 00:08:00.887+00	\N
091469a8-f3af-4a46-9c6e-015fe2b22bbd	\N	Alimentação Animal	OTHER	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	Destinatário genérico para alimentação animal - Recipient Global (disponível para todos)	["Alimentação Animal","Orgânicos"]	2025-11-16 00:08:00.887+00	2025-11-22 17:59:52.963+00	2025-11-22 17:59:52.963+00
\.


--
-- Data for Name: units; Type: TABLE DATA; Schema: public; Owner: cicloazul
--

COPY public.units (id, client_id, name, type, address, city, state, zip_code, latitude, longitude, responsible_name, responsible_phone, active, notes, created_at, updated_at, deleted_at) FROM stdin;
38aa841e-7439-4f63-bc6c-e29b05878cfc	7209ebbc-98f2-49b5-8023-7476ddeee8d4	Ponto 1 - Pq Eco	Parque Ecológico	Rodovia Bonito / Guia Lopes Da Laguna, S/N Km 07 - Zona Rural	Bonito	MS	79290-000	-21.12960000	-56.47310000	Responsável Parque	(67) 98162-5580	t	\N	2025-11-16 00:08:00.884+00	2025-11-16 00:08:00.884+00	\N
ee618271-fb2f-48a3-8be3-5186ced637a7	560d629c-b877-44fb-a79f-552bcd318aee	Ponto 1 - Restaurante Bacuri	Restaurante	Rua 24 de Fevereiro, 2268, Centro	Bonito	MS	79290-000	-21.12690000	-56.42860000	Responsável Bacuri	(67) 98473-8342	t	\N	2025-11-16 00:08:00.884+00	2025-11-16 00:08:00.884+00	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: cicloazul
--

COPY public.users (id, name, username, email, password, role, active, last_login_at, client_id, created_at, updated_at, deleted_at) FROM stdin;
006fb8dc-4d3b-4d8c-b3f0-1e0e35ef37f5	Administrador Bacuri	bacuri	bacuricozinharegional@gmail.com	$2b$10$9FaDGpnVtYRTlon41crDhuuB9Knht0KVF5Uuy3jkLiWec7ARRVs2W	CLIENT	t	2025-11-23 16:05:53.43+00	560d629c-b877-44fb-a79f-552bcd318aee	2025-11-16 00:08:00.781+00	2025-11-23 16:05:53.432+00	\N
6a4ace4e-5060-435c-b800-fe505fe08ec5	Administrador	admin	admin@cicloazul.com	$2b$10$XEgFoLR.GnAHuxVt3ErQ1Or78VjUvKPnvnRkRJULCa7jeYqUnvRaK	ADMIN	t	2025-11-23 17:47:31.84+00	\N	2025-11-16 00:08:00.666+00	2025-11-23 17:47:31.84+00	\N
1b38d0df-23f8-4b20-af12-76044ca4e12d	Administrador Parque Rio Formoso	parquerioformoso	financeiro@parquerioformoso.com.br	$2b$10$tM9KiYX2BH/IUmThYyh7suafgTGO3yxr05H.idtgh.5tH/JQHpZk2	CLIENT	t	2025-11-23 15:36:33.35+00	7209ebbc-98f2-49b5-8023-7476ddeee8d4	2025-11-16 00:08:00.781+00	2025-11-23 15:36:33.351+00	\N
\.


--
-- Data for Name: waste_types; Type: TABLE DATA; Schema: public; Owner: cicloazul
--

COPY public.waste_types (id, name, category, description, unit, active, created_at, updated_at, deleted_at) FROM stdin;
aad03eb4-3539-450a-b77f-130ee71c873e	Garrafa Pet	RECYCLABLE	Garrafas PET limpas e vazias	kg	t	2025-11-16 00:08:00.878+00	2025-11-16 00:08:00.878+00	\N
9ef6eb5f-91fb-40fa-8dd4-b29f5e8a55bb	Plástico Mole	RECYCLABLE	Sacolas plásticas, embalagens flexíveis	kg	t	2025-11-16 00:08:00.878+00	2025-11-16 00:08:00.878+00	\N
4f6268b8-bf14-49d1-a427-cb288bca35d8	Plástico Duro	RECYCLABLE	Embalagens rígidas, potes, tampas	kg	t	2025-11-16 00:08:00.878+00	2025-11-16 00:08:00.878+00	\N
986cedc0-03b4-4a97-acd0-251418813e58	Pet Óleo	RECYCLABLE	Garrafas PET contaminadas com óleo	kg	t	2025-11-16 00:08:00.878+00	2025-11-16 00:08:00.878+00	\N
46dcf1a7-021c-42b0-a1a1-1674fbc341e5	Embalagem Longa Vida	RECYCLABLE	Caixas Tetra Pak	kg	t	2025-11-16 00:08:00.878+00	2025-11-16 00:08:00.878+00	\N
9fea2fd7-bb95-4e2a-87d5-5102f74a89ba	Latas de Alumínio	RECYCLABLE	Latas de bebidas	kg	t	2025-11-16 00:08:00.878+00	2025-11-16 00:08:00.878+00	\N
a0d6d060-b857-4679-8944-a33f08473903	Metais em Geral	RECYCLABLE	Ferro, aço e outros metais	kg	t	2025-11-16 00:08:00.878+00	2025-11-16 00:08:00.878+00	\N
5b440a7d-b4f5-46a7-bdcd-ce4a0353d461	Papel	RECYCLABLE	Papel branco, colorido, jornais	kg	t	2025-11-16 00:08:00.878+00	2025-11-16 00:08:00.878+00	\N
ad6431b4-fc85-4a24-84df-a4e8bec3abc1	Cartonagem	RECYCLABLE	Caixas de papel, cartolinas	kg	t	2025-11-16 00:08:00.878+00	2025-11-16 00:08:00.878+00	\N
ea6c40ac-3c49-415d-8b98-e9b053f739c3	Papelão	RECYCLABLE	Caixas de papelão ondulado	kg	t	2025-11-16 00:08:00.878+00	2025-11-16 00:08:00.878+00	\N
c9263448-02b2-4eb5-8e0c-809788f7fc4f	Rejeito	OTHER	Material sem possibilidade de reaproveitamento	kg	t	2025-11-16 00:08:00.878+00	2025-11-16 00:08:00.878+00	\N
e1b23eec-1e65-4819-85e0-ecddf6123472	Orgânicos	ORGANIC	Restos de alimentos, cascas, folhas	kg	t	2025-11-16 00:08:00.878+00	2025-11-16 00:08:00.878+00	\N
1406ff0f-616c-40c4-bd7f-dbac8c00bcc8	Isopor	RECYCLABLE	Embalagens de isopor limpo	kg	t	2025-11-16 00:08:00.878+00	2025-11-16 00:08:00.878+00	\N
6bdf4172-1f3d-446a-9399-fdb90a9bc290	Caixotes	RECYCLABLE	Caixotes de madeira	unidade	t	2025-11-16 00:08:00.878+00	2025-11-16 00:08:00.878+00	\N
a255ed6c-0108-4024-8534-729b85533925	Tampinha de Garrafa	RECYCLABLE	Tampas plásticas de garrafas	kg	t	2025-11-16 00:08:00.878+00	2025-11-16 00:08:00.878+00	\N
8e23bc19-f38a-4ce1-a0ea-6716da308080	Vidro	RECYCLABLE	Garrafas, potes e cacos de vidro	kg	t	2025-11-16 00:08:00.878+00	2025-11-16 00:08:00.878+00	\N
efe6ba0f-c3a5-43f3-9686-1ad6e2a5e838	Neoprene	RECYCLABLE	Material de neoprene	kg	t	2025-11-16 00:08:00.878+00	2025-11-16 00:08:00.878+00	\N
136bc894-9f1a-48e5-b6a2-346a03849c25	Alimentação Animal	ORGANIC	Resíduos orgânicos destinados à alimentação animal	kg	t	2025-11-16 00:08:00.878+00	2025-11-16 00:08:00.878+00	\N
31d0bcd9-2c27-4634-b6c7-21443f06523e	Óleo	HAZARDOUS	Óleo de cozinha usado	L	t	2025-11-16 00:08:00.878+00	2025-11-16 00:08:00.878+00	\N
0857a511-42d8-4b0d-833c-283ac4ca86e8	Alumínio	RECYCLABLE	Latas e embalagens de alumínio	kg	t	2025-11-16 00:08:00.878+00	2025-11-16 00:08:00.878+00	\N
\.


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: client_waste_types client_waste_types_client_id_waste_type_id_key; Type: CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.client_waste_types
    ADD CONSTRAINT client_waste_types_client_id_waste_type_id_key UNIQUE (client_id, waste_type_id);


--
-- Name: client_waste_types client_waste_types_pkey; Type: CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.client_waste_types
    ADD CONSTRAINT client_waste_types_pkey PRIMARY KEY (id);


--
-- Name: clients clients_document_key; Type: CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_document_key UNIQUE (document);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: collections collections_pkey; Type: CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_pkey PRIMARY KEY (id);


--
-- Name: gravimetric_data gravimetric_data_pkey; Type: CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.gravimetric_data
    ADD CONSTRAINT gravimetric_data_pkey PRIMARY KEY (id);


--
-- Name: images images_pkey; Type: CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_pkey PRIMARY KEY (id);


--
-- Name: lgpd_consents lgpd_consents_pkey; Type: CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.lgpd_consents
    ADD CONSTRAINT lgpd_consents_pkey PRIMARY KEY (id);


--
-- Name: recipients recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.recipients
    ADD CONSTRAINT recipients_pkey PRIMARY KEY (id);


--
-- Name: units units_pkey; Type: CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.units
    ADD CONSTRAINT units_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: waste_types waste_types_name_key; Type: CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.waste_types
    ADD CONSTRAINT waste_types_name_key UNIQUE (name);


--
-- Name: waste_types waste_types_pkey; Type: CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.waste_types
    ADD CONSTRAINT waste_types_pkey PRIMARY KEY (id);


--
-- Name: client_waste_types_client_id_waste_type_id; Type: INDEX; Schema: public; Owner: cicloazul
--

CREATE UNIQUE INDEX client_waste_types_client_id_waste_type_id ON public.client_waste_types USING btree (client_id, waste_type_id);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: client_waste_types client_waste_types_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.client_waste_types
    ADD CONSTRAINT client_waste_types_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: client_waste_types client_waste_types_waste_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.client_waste_types
    ADD CONSTRAINT client_waste_types_waste_type_id_fkey FOREIGN KEY (waste_type_id) REFERENCES public.waste_types(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: collections collections_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: collections collections_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: collections collections_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public.recipients(id) ON UPDATE CASCADE;


--
-- Name: collections collections_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.units(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: collections collections_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: collections collections_waste_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_waste_type_id_fkey FOREIGN KEY (waste_type_id) REFERENCES public.waste_types(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: gravimetric_data gravimetric_data_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.gravimetric_data
    ADD CONSTRAINT gravimetric_data_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES public.collections(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: images images_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES public.collections(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lgpd_consents lgpd_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.lgpd_consents
    ADD CONSTRAINT lgpd_consents_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lgpd_consents lgpd_consents_collected_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.lgpd_consents
    ADD CONSTRAINT lgpd_consents_collected_by_fkey FOREIGN KEY (collected_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: recipients recipients_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.recipients
    ADD CONSTRAINT recipients_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: units units_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.units
    ADD CONSTRAINT units_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cicloazul
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

